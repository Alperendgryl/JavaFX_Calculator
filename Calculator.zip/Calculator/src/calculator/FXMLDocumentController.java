package calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Label label1;

    private double result = 0;
    private String currentNumberStr = "";
    private String lastOperation = "";

    private void calculate(String operation) {
        double currentNum = Double.parseDouble(currentNumberStr);
        switch (operation) {
            case "%": // only modula 10
                result = currentNum % 10;
                break;
            case "/":
                double dividend = 0; //bölünen, pay
                double divisor = 0; //bölen, payda
                try{
                    if(divisor == 0){
                        throw new ArithmeticException();
                    }
                    if(divisor == 0 && dividend == 0){
                        throw new ArithmeticException();
                    }
                    result = dividend / divisor;
                    label.setText(result + "");
                }
                catch (ArithmeticException exception){
                    resetCalculator("undefined", "division by zero");
                }
                break;
            case "*":
                if (result == 0) {
                    result = 1;
                    result = result * currentNum;
                    break;
                }
                result *= currentNum;
                break;
            case "-":
                if (result == 0) {
                    currentNum *= -1;
                    result = result - currentNum;
                    break;
                }
                result -= currentNum;
                break;
            case "+":
                result += currentNum;
                break;
            default:
                break;
        }
        currentNumberStr = "";
        label1.setText(result + " " + operation);
        label.setText(result + "");
    }

    @FXML
    private void addNumber(String number) {
        currentNumberStr += number;
        label.setText(currentNumberStr);
    }

    @FXML
    private void division(ActionEvent event) {
        lastOperation = "/";
        calculate(lastOperation);
    }

    @FXML
    private void multiplication(ActionEvent event) {
        lastOperation = "*";
        calculate(lastOperation);
    }

    @FXML
    private void substraction(ActionEvent event) {
        lastOperation = "-";
        calculate(lastOperation);
    }

    @FXML
    private void addition(ActionEvent event) {
        lastOperation = "+";
        calculate(lastOperation);
    }

    @FXML
    private void result(ActionEvent event) { //result = result + (operation) + currentNumber
        String temp = result + "" + lastOperation + "" + currentNumberStr + "=";
        String tempCurrent = currentNumberStr;
        calculate(lastOperation);
        label1.setText(temp);
        currentNumberStr = tempCurrent;
    }

    @FXML
    private void ce(ActionEvent event) {
        resetCalculator("0", "");
    }

    @FXML
    private void c(ActionEvent event) {
        resetCalculator("0", "");
    }
    
    @FXML
    private void delete(ActionEvent event) { //delete
        if (!currentNumberStr.equals("")) {
            currentNumberStr = removeLastChar(currentNumberStr);
            label.setText(currentNumberStr);
        }
    }

    @FXML
    private void oneOverX(ActionEvent event) { //1/x
        double currentNum = Double.parseDouble(currentNumberStr);
        try {
            if (currentNum != 0) {
                String resultStr = 1 / currentNum + "";
                setLabelText(resultStr);
            } else {
                throw new ArithmeticException();
            }
        } catch (ArithmeticException exception) {
            resetCalculator("undefined", "Division by zero");
            System.out.println("Division by zero : undefined");
        }
    }

    @FXML
    private void xSquare(ActionEvent event) { //x^2
        double currentNum = Double.parseDouble(currentNumberStr);
        String resultStr = currentNum * currentNum + "";
        setLabelText(resultStr);
    }

    @FXML
    private void rootX(ActionEvent event) { //rootX
        double currentNum = Double.parseDouble(currentNumberStr);
        String resultStr = Math.sqrt(currentNum) + "";
        setLabelText(resultStr);
    }

    @FXML
    private void mod(ActionEvent event) { //mod
        lastOperation = "%";
        calculate(lastOperation);
    }

    @FXML
    private void plusMinus(ActionEvent event) {
        double currentNum = Double.parseDouble(currentNumberStr);

        currentNum = currentNum * (-1);
        currentNumberStr = currentNum + "";
        label.setText(currentNum + "");
    }

    @FXML
    private void dot(ActionEvent event) {
        currentNumberStr += ".";
        label.setText(currentNumberStr);
    }

    @FXML
    private void nine(ActionEvent event) {
        addNumber("9");
    }

    @FXML
    private void eight(ActionEvent event) {
        addNumber("8");
    }

    @FXML
    private void seven(ActionEvent event) {
        addNumber("7");
    }

    @FXML
    private void six(ActionEvent event) {
        addNumber("6");
    }

    @FXML
    private void five(ActionEvent event) {
        addNumber("5");
    }

    @FXML
    private void four(ActionEvent event) {
        addNumber("4");
    }

    @FXML
    private void three(ActionEvent event) {
        addNumber("3");
    }

    @FXML
    private void two(ActionEvent event) {
        addNumber("2");
    }

    @FXML
    private void one(ActionEvent event) {
        addNumber("1");
    }

    @FXML
    private void zero(ActionEvent event) {
        addNumber("0");
    }

    private void setLabelText(String result) {
        label.setText(result);
        currentNumberStr = "";
    }

    private String removeLastChar(String number) {
        return number.substring(0, number.length() - 1);
    }

    private void resetCalculator(String labelText, String label1Text){
        result = 0;
        currentNumberStr = "";
        label.setText(labelText);
        label1.setText(label1Text);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}
